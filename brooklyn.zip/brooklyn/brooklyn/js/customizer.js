/* <![CDATA[ */
( function( $ ) {
	
	// for future use
		
} )( jQuery );
 /* ]]> */	
